//
//  map.hpp
//  Overworld
//
//  Created by Brendan Coppinger on 1/5/17.
//  Copyright © 2017 Brendan Coppinger. All rights reserved.
//

#ifndef map_hpp
#define map_hpp

#include <stdio.h>
/*class map {
    
private:
    float x=12;
    float y=10;
    std::string map
    
public:
    player(float height, float width);
    sf::Sprite getcharsprite();
    void move(float xchange, float ychange);
    void moveto(sf::Vector2f coord);
    void draw(sf::RenderWindow & window);
    
    
    
};
*/

#endif /* map_hpp */
